class sum():
    def myfunc(a, b):
      return int(a)+int(b)

    print(myfunc(3, 7))
